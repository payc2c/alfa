<?php
 session_start();
header('Location:index.html');
?>